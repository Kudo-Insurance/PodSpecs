//
//  safetyscoresdk.h
//  safetyscoresdk
//
//  Copyright © 2020 Autoliv. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for safetyscoresdk.
FOUNDATION_EXPORT double safetyscoresdkVersionNumber;

//! Project version string for safetyscoresdk.
FOUNDATION_EXPORT const unsigned char safetyscoresdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <safetyscoresdk/PublicHeader.h>


